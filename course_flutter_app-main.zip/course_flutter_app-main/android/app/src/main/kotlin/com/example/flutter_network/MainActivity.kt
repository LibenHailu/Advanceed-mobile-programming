package com.example.flutter_network

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
